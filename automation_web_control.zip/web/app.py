from flask import Flask, render_template, request, Response, jsonify
from web.controller import start_automation, stop_automation
from web.logger import log_queue
from projects.nexira import NexiraProject

app = Flask(__name__)

PROJECTS = {"nexira": NexiraProject}

@app.route("/")
def index():
    return render_template("index.html", projects=PROJECTS.keys())

@app.route("/start", methods=["POST"])
def start():
    project = request.form["project"]
    excel = request.form["excel"]
    concurrent = int(request.form["concurrent"])
    start_automation(PROJECTS[project], excel, concurrent)
    return jsonify({"status": "started"})

@app.route("/stop", methods=["POST"])
def stop():
    stop_automation()
    return jsonify({"status": "stopped"})

@app.route("/logs")
def logs():
    def stream():
        while True:
            msg = log_queue.get()
            yield f"data: {msg}\n\n"
    return Response(stream(), mimetype="text/event-stream")
