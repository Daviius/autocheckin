import threading

STOP_EVENT = threading.Event()
